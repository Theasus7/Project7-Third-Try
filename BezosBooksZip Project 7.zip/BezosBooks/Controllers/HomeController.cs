﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BezosBooks.Models;
using BezosBooks.Models.ViewModels;

namespace BezosBooks.Controllers
{
    public class HomeController : Controller
    {
        private IBezosBooksRepository repo;

        public HomeController(IBezosBooksRepository temp)
        {
            repo = temp;
        }

        public IActionResult Index(int pageNum = 1)
        {
            int pageSize = 10;

            var x = new ProjectsViewModel
            {
                Projects = repo.Projects
                .OrderBy(p => p.Title)
                .Skip((pageNum - 1) * pageSize)
                .Take(pageSize),

                PageInfo = new PageInfo
                {
                    TotalNumProjects = repo.Projects.Count(),
                    ProjectsPerPage = pageSize,
                    CurrentPage = pageNum

                }
            };
            return View(x);
        }
    }
}
