﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BezosBooks.Models
{
    public class EFBezosBooksRepository : IBezosBooksRepository
    {
        private BezosBooksContext context { get; set; }

        public EFBezosBooksRepository(BezosBooksContext temp)
        {
            context = temp;
        }
        public IQueryable<Project> Projects => context.Projects;

    }
}

